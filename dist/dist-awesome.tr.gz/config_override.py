#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
Override configuration
'''

__author__ = 'YiLIU'


configs = {
    'db': {
        'host': '127.0.0.1'
    }
}