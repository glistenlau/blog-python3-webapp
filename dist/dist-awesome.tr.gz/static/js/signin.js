$(function() {
    var vmAuth = new Vue({
        el: '#vm',
        data: {

            }
        })
    })